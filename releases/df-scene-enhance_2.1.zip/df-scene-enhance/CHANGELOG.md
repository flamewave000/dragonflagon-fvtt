# DF Scene Enhancement Changes

## Version 2.1
- Added localization for Brazil Portuguese, courtesy of [Renato Innocenti](https://github.com/rinnocenti).

## Version 2.0
- Fixed breaking issues with the latest 0.7.4+ builds of FoundryVTT
- Fixed Thumbnail Overrides.
- Fixed Player Scene Tab features.

## Version 1.3
- Fixed a breaking issue with scene directories

## Version 1.2
- Corrected the scenes tab for Players to only show the Navigation Name of a Scene and not the actual Scene name (when available).

## Version 1.1
- Added localization for French
