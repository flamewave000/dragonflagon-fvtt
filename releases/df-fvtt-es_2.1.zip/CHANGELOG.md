# Version 2.0
- Merged the Animated Login Page extension into the Enhancement Suite Extension
- **Animated Login:** Now displays a volume control that preserves the user's volume setting between viewings.
- **Animated Login:** Adds `mute` flag for the background image url that will mute the video and will not display the volume control.