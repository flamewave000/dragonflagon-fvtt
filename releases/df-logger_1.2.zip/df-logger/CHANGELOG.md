# Release 1.2
- Added ability to disable the auto-destruct part of the login messages.

# Release 1.1
- Changed Auto-Delete setting to a 1-30 slider