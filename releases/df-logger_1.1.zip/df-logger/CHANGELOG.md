# Release 1.1
- Changed Auto-Delete setting to a 1-30 slider