# DF Scene Enhancement Changes

## Version 1.3
- Fixed a breaking issue with scene directories

## Version 1.2
- Corrected the scenes tab for Players to only show the Navigation Name of a Scene and not the actual Scene name (when available).

## Version 1.1
- Added localization for French
